import { Package2, Star } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Package } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { formatDistanceToNow } from "date-fns";

export default function FavoritesPage() {
  const { user } = useAuth();
  const [favoritePackages, setFavoritePackages] = useState<Package[]>([]);

  // Query packages
  const { data: packages, isLoading } = useQuery<Package[]>({
    queryKey: ["/api/packages"],
    enabled: !!user,
  });

  // Filter to show only packages that the user has favorited
  useEffect(() => {
    if (packages && Array.isArray(packages) && packages.length > 0) {
      // This is a simplified version. In a real app, you would have a separate API endpoint
      // to fetch favorited packages, but for this example we'll filter client-side
      const favorites = packages.filter((pkg: Package) => (pkg.favorites || 0) > 0);
      setFavoritePackages(favorites);
    }
  }, [packages]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="container max-w-7xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col space-y-8">
        <div>
          <h1 className="text-3xl font-bold">My Favorite Packages</h1>
          <p className="text-gray-500 mt-2">Packages you've marked as favorites</p>
        </div>

        <Separator />

        {favoritePackages.length === 0 ? (
          <div className="bg-gray-50 p-10 rounded-lg text-center">
            <Star className="h-12 w-12 mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-medium text-gray-700">No Favorites Yet</h3>
            <p className="text-gray-500 mt-2">You haven't added any packages to your favorites.</p>
            <Button asChild className="mt-4">
              <Link href="/packages">Browse Packages</Link>
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoritePackages.map((pkg) => (
              <Card key={pkg.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">
                    <Link href={`/packages/view/${pkg.id}`} className="hover:underline hover:text-primary transition-colors">
                      {pkg.name}
                    </Link>
                  </CardTitle>
                  <CardDescription className="text-sm line-clamp-2">
                    {pkg.description || "No description provided"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="flex items-center">
                      <Package2 className="h-4 w-4 mr-1 text-gray-500" />
                      <span>{pkg.downloads || 0} downloads</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 mr-1 text-yellow-400" />
                      <span>{pkg.favorites || 0} favorites</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="pt-0 flex justify-between items-center">
                  <span className="text-xs text-gray-500">
                    Updated {formatDistanceToNow(new Date(pkg.updatedAt || pkg.createdAt || Date.now()), { addSuffix: true })}
                  </span>
                  <Button asChild size="sm" variant="outline">
                    <Link href={`/packages/view/${pkg.id}`}>View</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}