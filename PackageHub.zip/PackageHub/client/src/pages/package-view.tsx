import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import SidebarNav from "@/components/sidebar-nav";
import MobileHeader from "@/components/mobile-header";
import { Button } from "@/components/ui/button";
import { 
  Clock, 
  Download, 
  Copy, 
  Star, 
  StarOff, 
  Loader2, 
  ArrowLeft,
  AlertTriangle
} from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import CodeEditor from "@/components/editor/code-editor";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function PackageView() {
  const { username, version, fileName, extension, id } = useParams<{ 
    username?: string;
    version?: string;
    fileName?: string;
    extension?: string;
    id?: string;
  }>();
  
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  
  // Direct package file access via URL: /pkg/{username}/@{version}/{fileName}.{extension}
  const isDirectAccess = !!(username && version && fileName && extension);
  
  // Package view from package list: /packages/view/:id
  const isPackageView = !!id && !isDirectAccess;
  
  // Fetch package data if accessing via package ID
  const { 
    data: packageData, 
    isLoading: packageLoading,
    error: packageError
  } = useQuery({
    queryKey: isPackageView ? [`/api/packages/${id}`] : [null],
    enabled: isPackageView,
  });
  
  // Fetch package files if viewing package details
  const { 
    data: packageFiles, 
    isLoading: filesLoading 
  } = useQuery({
    queryKey: packageData?.versions && packageData.versions.length > 0 
      ? [`/api/versions/${packageData.versions[0].id}/files`] 
      : [null],
    enabled: !!packageData?.versions && packageData.versions.length > 0,
  });
  
  // For direct access, we need to fetch the content directly
  const {
    data: directContent,
    isLoading: directContentLoading,
    error: directContentError
  } = useQuery({
    queryKey: isDirectAccess ? [`/pkg/${username}/@${version}/${fileName}.${extension}`] : [null],
    enabled: isDirectAccess,
  });
  
  // Effect to select the first file when files are loaded
  useEffect(() => {
    if (packageFiles && packageFiles.length > 0 && !selectedFile) {
      setSelectedFile(packageFiles[0].id.toString());
    }
  }, [packageFiles, selectedFile]);
  
  // Selected file data
  const selectedFileData = packageFiles?.find(file => file.id.toString() === selectedFile);
  
  // Increment download count
  const downloadMutation = useMutation({
    mutationFn: async () => {
      if (isPackageView && packageData) {
        await apiRequest("POST", `/api/packages/${packageData.id}/download`);
      }
    },
  });
  
  // Toggle favorite
  const toggleFavoriteMutation = useMutation({
    mutationFn: async () => {
      if (isPackageView && packageData) {
        await apiRequest("POST", `/api/packages/${packageData.id}/favorite`, {
          add: !isFavorited,
        });
      }
    },
    onSuccess: () => {
      setIsFavorited(!isFavorited);
      if (isPackageView) {
        queryClient.invalidateQueries({ queryKey: [`/api/packages/${id}`] });
      }
      toast({
        title: isFavorited ? "Removed from favorites" : "Added to favorites",
        description: isFavorited 
          ? "Package has been removed from your favorites" 
          : "Package has been added to your favorites",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update favorites",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Download package
  const handleDownload = () => {
    if (isDirectAccess) {
      // For direct access, download the file content
      const blob = new Blob([directContent], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileName}.${extension}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else if (selectedFileData) {
      // For package view, download the selected file
      const blob = new Blob([selectedFileData.content], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${selectedFileData.fileName}.${selectedFileData.extension}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      // Track download
      downloadMutation.mutate();
    }
  };
  
  // Copy package URL to clipboard
  const copyToClipboard = () => {
    let url = "";
    
    if (isDirectAccess) {
      url = window.location.href;
    } else if (packageData && packageData.versions && packageData.versions.length > 0 && selectedFileData) {
      const version = packageData.versions[0].version;
      url = `${window.location.origin}/pkg/${packageData.user.username}/@${version}/${selectedFileData.fileName}.${selectedFileData.extension}`;
    }
    
    if (url) {
      navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      
      toast({
        title: "URL copied",
        description: "Package URL has been copied to clipboard.",
      });
    }
  };
  
  // Loading states
  const isLoading = (isPackageView && packageLoading) || 
                    (isDirectAccess && directContentLoading) || 
                    filesLoading;
  
  // Error states
  const hasError = (isPackageView && packageError) || 
                  (isDirectAccess && directContentError);
  
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-100">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
          <p className="text-gray-600">Loading package...</p>
        </div>
      </div>
    );
  }
  
  if (hasError) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-lg w-full">
          <div className="flex items-center text-red-500 mb-4">
            <AlertTriangle className="h-8 w-8 mr-3" />
            <h2 className="text-xl font-semibold">Package Not Found</h2>
          </div>
          <p className="text-gray-600 mb-6">
            The package you're looking for doesn't exist or you don't have permission to view it.
          </p>
          <div className="flex justify-between">
            <Button variant="outline" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Go Back
            </Button>
            <Button onClick={() => navigate("/packages")}>
              Browse Packages
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  // Direct access content display
  if (isDirectAccess) {
    const language = getLanguageFromExtension(extension || "");
    
    return (
      <div className="flex h-screen overflow-hidden bg-gray-100">
        <SidebarNav />
        
        <div className="flex flex-col flex-1 w-0 overflow-hidden">
          <MobileHeader />
          
          <main className="relative flex-1 overflow-y-auto focus:outline-none">
            <div className="py-6">
              <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <Button variant="outline" onClick={() => navigate(-1)} className="mr-4">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">
                      {fileName}.{extension}
                    </h1>
                    <Badge className="ml-3 bg-green-100 text-green-800 hover:bg-green-100">
                      @{version}
                    </Badge>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" onClick={copyToClipboard}>
                      {copied ? "Copied!" : "Copy URL"}
                      {copied ? <Check className="ml-2 h-4 w-4" /> : <Copy className="ml-2 h-4 w-4" />}
                    </Button>
                    <Button onClick={handleDownload}>
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
                
                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                  <div className="px-4 py-3 bg-gray-50 border-b flex justify-between items-center">
                    <div className="flex items-center">
                      <span className="font-medium text-gray-700">Author: </span>
                      <span className="ml-2 text-primary">{username}</span>
                    </div>
                  </div>
                  <div className="p-4">
                    <CodeEditor
                      value={directContent || ""}
                      onChange={() => {}}
                      language={language}
                      readOnly={true}
                    />
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }
  
  // Package view display
  if (packageData) {
    return (
      <div className="flex h-screen overflow-hidden bg-gray-100">
        <SidebarNav />
        
        <div className="flex flex-col flex-1 w-0 overflow-hidden">
          <MobileHeader />
          
          <main className="relative flex-1 overflow-y-auto focus:outline-none">
            <div className="py-6">
              <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <Button variant="outline" onClick={() => navigate(-1)} className="mr-4">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">
                      {packageData.name}
                    </h1>
                    {packageData.latestVersion && (
                      <Badge className="ml-3 bg-green-100 text-green-800 hover:bg-green-100">
                        v{packageData.latestVersion.version}
                      </Badge>
                    )}
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      variant="ghost" 
                      onClick={() => toggleFavoriteMutation.mutate()}
                      disabled={!user || toggleFavoriteMutation.isPending}
                    >
                      {isFavorited ? (
                        <StarOff className="h-5 w-5 text-gray-500" />
                      ) : (
                        <Star className="h-5 w-5 text-yellow-400" />
                      )}
                    </Button>
                    <Button variant="outline" onClick={copyToClipboard}>
                      {copied ? "Copied!" : "Copy URL"}
                      {copied ? <Check className="ml-2 h-4 w-4" /> : <Copy className="ml-2 h-4 w-4" />}
                    </Button>
                    <Button onClick={handleDownload}>
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
                
                <div className="bg-white shadow-md rounded-lg overflow-hidden mb-6">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                      <div className="mb-4 md:mb-0">
                        <h2 className="text-lg font-medium text-gray-900">Package Details</h2>
                        <p className="mt-1 text-sm text-gray-500">
                          {packageData.description || "No description provided."}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-4">
                        <div className="flex items-center">
                          <Download className="h-5 w-5 text-gray-400 mr-2" />
                          <span className="text-gray-900 font-medium">{packageData.downloads}</span>
                          <span className="ml-1 text-gray-500">downloads</span>
                        </div>
                        <div className="flex items-center">
                          <Star className="h-5 w-5 text-yellow-400 mr-2" />
                          <span className="text-gray-900 font-medium">{packageData.favorites}</span>
                          <span className="ml-1 text-gray-500">favorites</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-5 w-5 text-gray-400 mr-2" />
                          <span className="text-gray-500">
                            Updated {new Date(packageData.updatedAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex items-center">
                      <span className="text-gray-700 mr-2">Author:</span>
                      <span className="text-primary">{packageData.user.username}</span>
                    </div>
                    
                    <div className="mt-2">
                      <span className="text-gray-700 mr-2">Visibility:</span>
                      <Badge className={packageData.isPublic ? "bg-green-100 text-green-800" : "bg-gray-100"}>
                        {packageData.isPublic ? "Public" : "Private"}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                {packageFiles && packageFiles.length > 0 ? (
                  <div className="bg-white shadow-md rounded-lg overflow-hidden">
                    <Tabs defaultValue={selectedFile || packageFiles[0].id.toString()}>
                      <div className="px-4 pt-3 border-b">
                        <TabsList className="h-10">
                          {packageFiles.map((file) => (
                            <TabsTrigger
                              key={file.id}
                              value={file.id.toString()}
                              onClick={() => setSelectedFile(file.id.toString())}
                            >
                              {file.fileName}.{file.extension}
                            </TabsTrigger>
                          ))}
                        </TabsList>
                      </div>
                      
                      {packageFiles.map((file) => (
                        <TabsContent key={file.id} value={file.id.toString()} className="p-0">
                          <div className="p-4">
                            <CodeEditor
                              value={file.content}
                              onChange={() => {}}
                              language={file.language}
                              readOnly={true}
                            />
                          </div>
                        </TabsContent>
                      ))}
                    </Tabs>
                  </div>
                ) : (
                  <div className="bg-white shadow-md rounded-lg p-8 text-center">
                    <p className="text-gray-500">No files available for this package.</p>
                  </div>
                )}
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }
  
  return null;
}

function Check(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

function getLanguageFromExtension(extension: string): string {
  const map: Record<string, string> = {
    'js': 'javascript',
    'ts': 'typescript',
    'jsx': 'javascript',
    'tsx': 'typescript',
    'html': 'html',
    'css': 'css',
    'json': 'json',
  };
  
  return map[extension.toLowerCase()] || 'text';
}
