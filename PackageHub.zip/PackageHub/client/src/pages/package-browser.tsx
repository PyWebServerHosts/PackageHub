import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import SidebarNav from "@/components/sidebar-nav";
import MobileHeader from "@/components/mobile-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search, Star, Download, Eye } from "lucide-react";
import { PackageWithDetails } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface PackageBrowserProps {
  userOnly?: boolean;
  params?: any;
}

export default function PackageBrowser({ userOnly = false, params }: PackageBrowserProps) {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortOrder, setSortOrder] = useState("popular");
  
  // Fetch packages
  const { data: packages, isLoading } = useQuery<PackageWithDetails[]>({
    queryKey: userOnly 
      ? [`/api/packages?userId=${user?.id}`]
      : searchQuery 
        ? [`/api/packages/search?q=${searchQuery}`]
        : ["/api/packages"],
  });
  
  // Filter and sort packages
  const filteredPackages = packages ? [...packages] : [];
  
  // Sort packages
  if (filteredPackages.length > 0) {
    if (sortOrder === "popular") {
      filteredPackages.sort((a, b) => (b.downloads + b.favorites) - (a.downloads + a.favorites));
    } else if (sortOrder === "recent") {
      filteredPackages.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    } else if (sortOrder === "name") {
      filteredPackages.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortOrder === "downloads") {
      filteredPackages.sort((a, b) => b.downloads - a.downloads);
    }
  }
  
  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      <SidebarNav />
      
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <MobileHeader />
        
        <main className="relative flex-1 overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-gray-900">
                {userOnly ? "My Packages" : "Browse Packages"}
              </h1>
            </div>
            <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
              <div className="py-4">
                {/* Search and Filter */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-3 md:space-y-0 mb-6">
                  <div className="w-full md:w-1/2">
                    <form onSubmit={handleSearch}>
                      <div className="relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Search className="h-5 w-5 text-gray-400" />
                        </div>
                        <Input
                          placeholder="Search packages..."
                          className="pl-10"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                    </form>
                  </div>
                  <div className="flex space-x-2">
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="ui-components">UI Components</SelectItem>
                        <SelectItem value="utilities">Utilities</SelectItem>
                        <SelectItem value="data-handling">Data Handling</SelectItem>
                        <SelectItem value="state-management">State Management</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={sortOrder} onValueChange={setSortOrder}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Sort by: Popularity" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="popular">Sort by: Popularity</SelectItem>
                        <SelectItem value="recent">Sort by: Recent</SelectItem>
                        <SelectItem value="name">Sort by: Name (A-Z)</SelectItem>
                        <SelectItem value="downloads">Sort by: Downloads</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Package List */}
                <div className="bg-white shadow overflow-hidden sm:rounded-md">
                  {isLoading ? (
                    <div className="flex justify-center p-8">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : filteredPackages.length > 0 ? (
                    <ul className="divide-y divide-gray-200">
                      {filteredPackages.map((pkg) => (
                        <li key={pkg.id}>
                          <div className="px-4 py-4 sm:px-6">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <h3 className="text-lg font-medium text-primary">{pkg.name}</h3>
                                <span className="ml-2 px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full">
                                  v{pkg.latestVersion?.version || "1.0.0"}
                                </span>
                              </div>
                              <div className="flex space-x-2">
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <Star className="h-4 w-4 text-gray-500" />
                                </Button>
                                <Button variant="outline" size="sm" className="flex items-center">
                                  <Download className="h-4 w-4 mr-1" />
                                  Install
                                </Button>
                                <Button 
                                  size="sm" 
                                  onClick={() => navigate(`/packages/view/${pkg.id}`)}
                                >
                                  <Eye className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                              </div>
                            </div>
                            <div className="mt-2 sm:flex sm:justify-between">
                              <div className="sm:flex">
                                <p className="flex items-center text-sm text-gray-500">
                                  <User className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                  {pkg.user.username}
                                </p>
                                <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                                  <Download className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                  {pkg.downloads} downloads
                                </p>
                                <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                                  <Star className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                  {pkg.favorites}
                                </p>
                              </div>
                              <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                <p>
                                  Updated{" "}
                                  {new Date(pkg.updatedAt).toLocaleDateString(undefined, {
                                    year: "numeric",
                                    month: "short",
                                    day: "numeric",
                                  })}
                                </p>
                              </div>
                            </div>
                            <div className="mt-2">
                              <p className="text-sm text-gray-700">
                                {pkg.description || "No description provided."}
                              </p>
                              <div className="mt-2">
                                {/* Placeholder tags - in a real app these would come from the package */}
                                <Badge variant="outline" className="mr-1 bg-blue-100 text-blue-800 hover:bg-blue-100">
                                  javascript
                                </Badge>
                                <Badge variant="outline" className="mr-1 bg-blue-100 text-blue-800 hover:bg-blue-100">
                                  utilities
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-gray-500">No packages found.</p>
                      {userOnly && (
                        <Button
                          className="mt-4"
                          onClick={() => navigate("/packages/edit")}
                        >
                          Create a package
                        </Button>
                      )}
                    </div>
                  )}
                </div>

                {/* Add pagination here if implemented */}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

// Simple user icon component to avoid importing the whole Lucide library
function User(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

// Simple calendar icon component
function Calendar(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}
