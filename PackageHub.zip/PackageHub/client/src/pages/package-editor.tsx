import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import SidebarNav from "@/components/sidebar-nav";
import MobileHeader from "@/components/mobile-header";
import CodeEditor from "@/components/editor/code-editor";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Loader2, EyeIcon, Save, Clipboard, Copy, CheckIcon } from "lucide-react";
import { Package, PackageFile, PackageVersion } from "@shared/schema";

// Form schema for package
const packageSchema = z.object({
  name: z.string().min(1, "Package name is required").regex(/^[a-zA-Z0-9_-]+$/, "Only letters, numbers, underscores, and hyphens are allowed"),
  description: z.string().optional(),
  isPublic: z.boolean().default(true),
  minify: z.boolean().default(false),
  enableCache: z.boolean().default(true),
});

// Form schema for file
const fileSchema = z.object({
  fileName: z.string().min(1, "File name is required").regex(/^[a-zA-Z0-9_-]+$/, "Only letters, numbers, underscores, and hyphens are allowed"),
  extension: z.string().min(1, "Extension is required"),
  language: z.string().min(1, "Language is required"),
  content: z.string(),
});

// Form schema for version
const versionSchema = z.object({
  version: z.string().regex(/^\d+\.\d+\.\d+$/, "Version must follow semver format (e.g., 1.0.0)"),
});

type PackageFormValues = z.infer<typeof packageSchema>;
type FileFormValues = z.infer<typeof fileSchema>;
type VersionFormValues = z.infer<typeof versionSchema>;

export default function PackageEditor() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeVersion, setActiveVersion] = useState<string | null>(null);
  const [activeFile, setActiveFile] = useState<PackageFile | null>(null);
  const [copied, setCopied] = useState(false);
  const [isCreatingVersion, setIsCreatingVersion] = useState(false);
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  
  // Set up forms
  const packageForm = useForm<PackageFormValues>({
    resolver: zodResolver(packageSchema),
    defaultValues: {
      name: "",
      description: "",
      isPublic: true,
      minify: false,
      enableCache: true,
    },
  });
  
  const fileForm = useForm<FileFormValues>({
    resolver: zodResolver(fileSchema),
    defaultValues: {
      fileName: "index",
      extension: "js",
      language: "javascript",
      content: "",
    },
  });
  
  const versionForm = useForm<VersionFormValues>({
    resolver: zodResolver(versionSchema),
    defaultValues: {
      version: "1.0.0",
    },
  });
  
  // Fetch package data if editing existing package
  const { data: packageData, isLoading: packageLoading } = useQuery<Package & { versions: PackageVersion[] }>({
    queryKey: [`/api/packages/${id}`],
    enabled: !!id,
  });
  
  // Fetch versions for the package
  const { data: versions, isLoading: versionsLoading } = useQuery<PackageVersion[]>({
    queryKey: [`/api/packages/${id}/versions`],
    enabled: !!id,
  });
  
  // Fetch files for the active version
  const { data: files, isLoading: filesLoading } = useQuery<PackageFile[]>({
    queryKey: [`/api/versions/${activeVersion}/files`],
    enabled: !!activeVersion,
  });
  
  // Create package mutation
  const createPackageMutation = useMutation({
    mutationFn: async (data: PackageFormValues) => {
      const res = await apiRequest("POST", "/api/packages", {
        ...data,
        userId: user!.id,
      });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Package created",
        description: "Your package has been created successfully.",
      });
      navigate(`/packages/edit/${data.id}`);
      queryClient.invalidateQueries({ queryKey: [`/api/packages?userId=${user!.id}`] });
    },
    onError: (error) => {
      toast({
        title: "Failed to create package",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update package mutation
  const updatePackageMutation = useMutation({
    mutationFn: async (data: PackageFormValues) => {
      const res = await apiRequest("PATCH", `/api/packages/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Package updated",
        description: "Your package has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/packages/${id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/packages?userId=${user!.id}`] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update package",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Create version mutation
  const createVersionMutation = useMutation({
    mutationFn: async (data: VersionFormValues) => {
      const res = await apiRequest("POST", `/api/packages/${id}/versions`, data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Version created",
        description: "Version has been created successfully.",
      });
      setIsCreatingVersion(false);
      setActiveVersion(data.id.toString());
      queryClient.invalidateQueries({ queryKey: [`/api/packages/${id}/versions`] });
      queryClient.invalidateQueries({ queryKey: [`/api/packages/${id}`] });
      versionForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to create version",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Create file mutation
  const createFileMutation = useMutation({
    mutationFn: async (data: FileFormValues) => {
      const res = await apiRequest("POST", `/api/versions/${activeVersion}/files`, data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "File created",
        description: "File has been created successfully.",
      });
      setIsCreatingFile(false);
      setActiveFile(data);
      queryClient.invalidateQueries({ queryKey: [`/api/versions/${activeVersion}/files`] });
      fileForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to create file",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update file mutation
  const updateFileMutation = useMutation({
    mutationFn: async (data: FileFormValues) => {
      const res = await apiRequest("PATCH", `/api/files/${activeFile?.id}`, data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "File updated",
        description: "File has been updated successfully.",
      });
      setActiveFile(data);
      queryClient.invalidateQueries({ queryKey: [`/api/versions/${activeVersion}/files`] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update file",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Load package data into form
  useEffect(() => {
    if (packageData) {
      packageForm.reset({
        name: packageData.name,
        description: packageData.description || "",
        isPublic: packageData.isPublic,
        minify: packageData.minify,
        enableCache: packageData.enableCache,
      });
      
      // Set active version to the latest one
      if (packageData.versions && packageData.versions.length > 0 && !activeVersion) {
        const sortedVersions = [...packageData.versions].sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setActiveVersion(sortedVersions[0].id.toString());
      }
    }
  }, [packageData]);
  
  // Load file data into form
  useEffect(() => {
    if (activeFile) {
      fileForm.reset({
        fileName: activeFile.fileName,
        extension: activeFile.extension,
        language: activeFile.language,
        content: activeFile.content,
      });
    }
  }, [activeFile]);
  
  // Handle selecting a file
  const handleFileSelect = (file: PackageFile) => {
    setActiveFile(file);
  };
  
  // Handle selecting a version
  const handleVersionSelect = (versionId: string) => {
    setActiveVersion(versionId);
    setActiveFile(null);
  };
  
  // Handle package form submission
  const onPackageSubmit = (data: PackageFormValues) => {
    if (id) {
      updatePackageMutation.mutate(data);
    } else {
      createPackageMutation.mutate(data);
    }
  };
  
  // Handle version form submission
  const onVersionSubmit = (data: VersionFormValues) => {
    createVersionMutation.mutate(data);
  };
  
  // Handle file form submission
  const onFileSubmit = (data: FileFormValues) => {
    if (activeFile) {
      updateFileMutation.mutate(data);
    } else {
      createFileMutation.mutate(data);
    }
  };
  
  // Get package URL for clipboard
  const getPackageUrl = () => {
    if (!packageData || !activeVersion || !activeFile) return "";
    
    const version = versions?.find(v => v.id.toString() === activeVersion);
    if (!version) return "";
    
    return `/pkg/${user?.username}/@${version.version}/${activeFile.fileName}.${activeFile.extension}`;
  };
  
  // Copy package URL to clipboard
  const copyToClipboard = () => {
    const url = getPackageUrl();
    if (url) {
      navigator.clipboard.writeText(window.location.origin + url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      
      toast({
        title: "URL copied",
        description: "Package URL has been copied to clipboard.",
      });
    }
  };
  
  const isLoading = packageLoading || versionsLoading || (!!activeVersion && filesLoading);
  
  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      <SidebarNav />
      
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <MobileHeader />
        
        <main className="relative flex-1 overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
              <div className="flex items-center justify-between">
                <h1 className="text-2xl font-semibold text-gray-900">
                  {id ? "Edit Package" : "Create Package"}
                </h1>
                <div className="flex space-x-3">
                  {packageData && activeFile && (
                    <Button variant="outline" onClick={() => window.open(getPackageUrl(), "_blank")}>
                      <EyeIcon className="w-4 h-4 mr-2" />
                      Preview
                    </Button>
                  )}
                  <Button
                    type="submit"
                    form="package-form"
                    disabled={createPackageMutation.isPending || updatePackageMutation.isPending}
                  >
                    {(createPackageMutation.isPending || updatePackageMutation.isPending) && (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    )}
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                </div>
              </div>
            </div>
            
            {isLoading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
                <div className="py-4">
                  {/* Package Information Form */}
                  <div className="bg-white shadow rounded-lg mb-6">
                    <div className="px-4 py-5 sm:p-6">
                      <Form {...packageForm}>
                        <form
                          id="package-form"
                          onSubmit={packageForm.handleSubmit(onPackageSubmit)}
                          className="space-y-6"
                        >
                          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                            <FormField
                              control={packageForm.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Package Name</FormLabel>
                                  <FormControl>
                                    <Input placeholder="my-package" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            {id && versions && (
                              <div>
                                <FormLabel>Version</FormLabel>
                                <div className="flex gap-2">
                                  <Select
                                    value={activeVersion || ""}
                                    onValueChange={handleVersionSelect}
                                  >
                                    <SelectTrigger className="w-full">
                                      <SelectValue placeholder="Select version" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {versions.map((version) => (
                                        <SelectItem key={version.id} value={version.id.toString()}>
                                          v{version.version}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => setIsCreatingVersion(true)}
                                  >
                                    + New
                                  </Button>
                                </div>
                              </div>
                            )}
                            
                            <FormField
                              control={packageForm.control}
                              name="description"
                              render={({ field }) => (
                                <FormItem className="sm:col-span-2">
                                  <FormLabel>Description</FormLabel>
                                  <FormControl>
                                    <Textarea
                                      placeholder="A brief description of your package"
                                      className="resize-none"
                                      {...field}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </form>
                      </Form>
                    </div>
                  </div>
                  
                  {isCreatingVersion && id && (
                    <div className="bg-white shadow rounded-lg mb-6">
                      <div className="px-4 py-5 sm:p-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">Create New Version</h3>
                        <Form {...versionForm}>
                          <form
                            onSubmit={versionForm.handleSubmit(onVersionSubmit)}
                            className="space-y-4"
                          >
                            <FormField
                              control={versionForm.control}
                              name="version"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Version Number</FormLabel>
                                  <FormControl>
                                    <Input placeholder="1.0.0" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <div className="flex justify-end gap-2">
                              <Button
                                type="button"
                                variant="outline"
                                onClick={() => setIsCreatingVersion(false)}
                              >
                                Cancel
                              </Button>
                              <Button
                                type="submit"
                                disabled={createVersionMutation.isPending}
                              >
                                {createVersionMutation.isPending && (
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                )}
                                Create Version
                              </Button>
                            </div>
                          </form>
                        </Form>
                      </div>
                    </div>
                  )}
                  
                  {id && activeVersion && (
                    <>
                      {/* File Selection & Editor */}
                      <div className="bg-white shadow rounded-lg overflow-hidden mb-6">
                        <div className="px-4 py-5 sm:p-6">
                          <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-medium text-gray-900">Files</h3>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => {
                                setActiveFile(null);
                                setIsCreatingFile(true);
                                fileForm.reset({
                                  fileName: "index",
                                  extension: "js",
                                  language: "javascript",
                                  content: "",
                                });
                              }}
                            >
                              + New File
                            </Button>
                          </div>
                          
                          {/* File tabs */}
                          <div className="mb-4 border-b border-gray-200">
                            <div className="flex overflow-x-auto">
                              {files?.map((file) => (
                                <div
                                  key={file.id}
                                  className={`px-4 py-2 cursor-pointer whitespace-nowrap ${
                                    activeFile?.id === file.id
                                      ? "border-b-2 border-primary text-primary"
                                      : "text-gray-600 hover:text-gray-900"
                                  }`}
                                  onClick={() => handleFileSelect(file)}
                                >
                                  {file.fileName}.{file.extension}
                                </div>
                              ))}
                              {files && files.length === 0 && !isCreatingFile && (
                                <div className="px-4 py-2 text-gray-500 italic">
                                  No files yet. Create one to get started.
                                </div>
                              )}
                            </div>
                          </div>
                          
                          {/* File editor form */}
                          {(activeFile || isCreatingFile) && (
                            <Form {...fileForm}>
                              <form
                                onSubmit={fileForm.handleSubmit(onFileSubmit)}
                                className="space-y-4"
                              >
                                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                                  <FormField
                                    control={fileForm.control}
                                    name="fileName"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>File Name</FormLabel>
                                        <FormControl>
                                          <Input placeholder="index" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  
                                  <FormField
                                    control={fileForm.control}
                                    name="extension"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Extension</FormLabel>
                                        <FormControl>
                                          <Input placeholder="js" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  
                                  <FormField
                                    control={fileForm.control}
                                    name="language"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Language</FormLabel>
                                        <Select
                                          value={field.value}
                                          onValueChange={field.onChange}
                                        >
                                          <SelectTrigger>
                                            <SelectValue placeholder="Select language" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="javascript">JavaScript</SelectItem>
                                            <SelectItem value="typescript">TypeScript</SelectItem>
                                            <SelectItem value="html">HTML</SelectItem>
                                            <SelectItem value="css">CSS</SelectItem>
                                            <SelectItem value="json">JSON</SelectItem>
                                            <SelectItem value="text">Plain Text</SelectItem>
                                          </SelectContent>
                                        </Select>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                </div>
                                
                                <FormField
                                  control={fileForm.control}
                                  name="content"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Content</FormLabel>
                                      <FormControl>
                                        <CodeEditor
                                          value={field.value}
                                          onChange={field.onChange}
                                          language={fileForm.watch("language")}
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <div className="flex justify-between">
                                  <div>
                                    {activeFile && packageData && (
                                      <div className="flex items-center text-sm text-gray-500">
                                        Package URL:{" "}
                                        <code className="mx-2 font-mono text-primary">
                                          {getPackageUrl()}
                                        </code>
                                        <Button
                                          type="button"
                                          variant="ghost"
                                          size="sm"
                                          onClick={copyToClipboard}
                                          className="h-8 px-2"
                                        >
                                          {copied ? (
                                            <CheckIcon className="w-4 h-4 text-green-500" />
                                          ) : (
                                            <Copy className="w-4 h-4" />
                                          )}
                                        </Button>
                                      </div>
                                    )}
                                  </div>
                                  <div className="flex gap-2">
                                    {isCreatingFile && (
                                      <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() => setIsCreatingFile(false)}
                                      >
                                        Cancel
                                      </Button>
                                    )}
                                    <Button
                                      type="submit"
                                      disabled={createFileMutation.isPending || updateFileMutation.isPending}
                                    >
                                      {(createFileMutation.isPending || updateFileMutation.isPending) && (
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                      )}
                                      {activeFile ? "Update File" : "Create File"}
                                    </Button>
                                  </div>
                                </div>
                              </form>
                            </Form>
                          )}
                        </div>
                      </div>
                      
                      {/* Package Settings */}
                      <div className="bg-white shadow rounded-lg overflow-hidden">
                        <div className="px-4 py-5 sm:p-6">
                          <h3 className="text-lg font-medium text-gray-900 mb-4">Package Settings</h3>
                          
                          <div className="space-y-4">
                            {/* Visibility */}
                            <div>
                              <h4 className="text-sm font-medium text-gray-900 mb-2">Visibility</h4>
                              <FormField
                                control={packageForm.control}
                                name="isPublic"
                                render={({ field }) => (
                                  <RadioGroup
                                    onValueChange={(value) => field.onChange(value === "public")}
                                    defaultValue={field.value ? "public" : "private"}
                                    className="space-y-3"
                                  >
                                    <div className="flex items-start space-x-3">
                                      <RadioGroupItem value="public" id="public" />
                                      <div>
                                        <label htmlFor="public" className="font-medium text-gray-700">
                                          Public
                                        </label>
                                        <p className="text-sm text-gray-500">
                                          Anyone can view and use this package
                                        </p>
                                      </div>
                                    </div>
                                    <div className="flex items-start space-x-3">
                                      <RadioGroupItem value="private" id="private" />
                                      <div>
                                        <label htmlFor="private" className="font-medium text-gray-700">
                                          Private
                                        </label>
                                        <p className="text-sm text-gray-500">
                                          Only you can view and use this package
                                        </p>
                                      </div>
                                    </div>
                                  </RadioGroup>
                                )}
                              />
                            </div>
                            
                            {/* CDN Settings */}
                            <div className="pt-4 border-t border-gray-200">
                              <h4 className="text-sm font-medium text-gray-900 mb-2">CDN Optimization</h4>
                              
                              <div className="space-y-3">
                                <FormField
                                  control={packageForm.control}
                                  name="minify"
                                  render={({ field }) => (
                                    <div className="flex items-start space-x-3">
                                      <Checkbox
                                        id="minify"
                                        checked={field.value}
                                        onCheckedChange={field.onChange}
                                      />
                                      <div>
                                        <label
                                          htmlFor="minify"
                                          className="font-medium text-gray-700"
                                        >
                                          Minify code
                                        </label>
                                        <p className="text-sm text-gray-500">
                                          Automatically minify code for CDN delivery
                                        </p>
                                      </div>
                                    </div>
                                  )}
                                />
                                
                                <FormField
                                  control={packageForm.control}
                                  name="enableCache"
                                  render={({ field }) => (
                                    <div className="flex items-start space-x-3">
                                      <Checkbox
                                        id="cache"
                                        checked={field.value}
                                        onCheckedChange={field.onChange}
                                      />
                                      <div>
                                        <label
                                          htmlFor="cache"
                                          className="font-medium text-gray-700"
                                        >
                                          Enable caching
                                        </label>
                                        <p className="text-sm text-gray-500">
                                          Cache package for faster delivery
                                        </p>
                                      </div>
                                    </div>
                                  )}
                                />
                              </div>
                            </div>
                            
                            {/* Version History */}
                            {id && versions && versions.length > 0 && (
                              <div className="pt-4 border-t border-gray-200">
                                <h4 className="text-sm font-medium text-gray-900 mb-2">
                                  Version History
                                </h4>
                                
                                <div className="bg-gray-50 rounded-md p-3 max-h-40 overflow-y-auto">
                                  <ul className="space-y-2 text-sm">
                                    {versions
                                      .sort((a, b) => {
                                        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
                                      })
                                      .map((version) => (
                                        <li
                                          key={version.id}
                                          className="flex items-center justify-between"
                                        >
                                          <div>
                                            <span className="font-medium">v{version.version}</span>
                                            {activeVersion === version.id.toString() && (
                                              <span className="text-gray-500 ml-2">Current</span>
                                            )}
                                          </div>
                                          <span className="text-gray-500">
                                            {new Date(version.createdAt).toLocaleDateString()}
                                          </span>
                                        </li>
                                      ))}
                                  </ul>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
