import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import SidebarNav from "@/components/sidebar-nav";
import MobileHeader from "@/components/mobile-header";
import StatsCard from "@/components/stats-card";
import ActivityItem from "@/components/activity-item";
import PackageCard from "@/components/package-card";
import { Loader2 } from "lucide-react";
import { PackageWithDetails, ActivityWithDetails } from "@shared/schema";

export default function HomePage() {
  const { user } = useAuth();
  
  const { data: activities, isLoading: activitiesLoading } = useQuery<ActivityWithDetails[]>({
    queryKey: ["/api/activities"],
  });
  
  const { data: userPackages, isLoading: packagesLoading } = useQuery<PackageWithDetails[]>({
    queryKey: [`/api/packages?userId=${user?.id}`],
  });
  
  const { data: popularPackages, isLoading: popularLoading } = useQuery<PackageWithDetails[]>({
    queryKey: ["/api/packages/popular"],
  });
  
  // Calculate stats
  const stats = {
    totalPackages: userPackages?.length || 0,
    totalDownloads: userPackages?.reduce((sum, pkg) => sum + pkg.downloads, 0) || 0,
    favorites: userPackages?.reduce((sum, pkg) => sum + pkg.favorites, 0) || 0,
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-100">
      <SidebarNav />
      
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <MobileHeader />
        
        <main className="relative flex-1 overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
            </div>
            <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
              <div className="py-4">
                {/* Dashboard Stats */}
                <div className="grid gap-4 md:grid-cols-3">
                  <StatsCard
                    title="Total Packages"
                    value={stats.totalPackages}
                    icon="ri-archive-line"
                    color="blue"
                  />
                  <StatsCard
                    title="Total Downloads"
                    value={stats.totalDownloads}
                    icon="ri-download-line"
                    color="green"
                  />
                  <StatsCard
                    title="Favorites"
                    value={stats.favorites}
                    icon="ri-star-line"
                    color="purple"
                  />
                </div>

                {/* Recent Activity */}
                <div className="mt-6">
                  <h2 className="mb-4 text-lg font-medium text-gray-900">Recent Activity</h2>
                  <div className="overflow-hidden bg-white shadow sm:rounded-md">
                    {activitiesLoading ? (
                      <div className="flex justify-center p-6">
                        <Loader2 className="h-6 w-6 animate-spin text-primary" />
                      </div>
                    ) : activities && activities.length > 0 ? (
                      <ul className="divide-y divide-gray-200">
                        {activities.map((activity) => (
                          <ActivityItem key={activity.id} activity={activity} />
                        ))}
                      </ul>
                    ) : (
                      <div className="p-6 text-center text-gray-500">
                        No recent activity found.
                      </div>
                    )}
                  </div>
                </div>

                {/* Popular Packages */}
                <div className="mt-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-medium text-gray-900">Popular Packages</h2>
                    <Link href="/packages" className="text-sm font-medium text-primary hover:text-blue-700">
                      View all
                    </Link>
                  </div>
                  
                  {popularLoading ? (
                    <div className="flex justify-center p-6">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  ) : (
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {popularPackages?.map((pkg) => (
                        <PackageCard key={pkg.id} package={pkg} />
                      ))}
                      
                      {(!popularPackages || popularPackages.length === 0) && (
                        <div className="col-span-3 p-6 text-center text-gray-500 bg-white rounded-lg shadow">
                          No packages found. Be the first to create one!
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
