import { useRef, useEffect } from "react";
import { Editor } from "@monaco-editor/react";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: string;
  readOnly?: boolean;
  height?: string;
  className?: string;
}

export default function CodeEditor({
  value,
  onChange,
  language,
  readOnly = false,
  height = "400px",
  className,
}: CodeEditorProps) {
  const editorRef = useRef<any>(null);
  
  useEffect(() => {
    // Format code when editor mounts
    if (editorRef.current) {
      setTimeout(() => {
        editorRef.current?.getAction("editor.action.formatDocument")?.run();
      }, 100);
    }
  }, [editorRef.current]);
  
  // Handle editor mount
  const handleEditorDidMount = (editor: any) => {
    editorRef.current = editor;
    
    // Add keyboard shortcut for formatting (Shift+Alt+F)
    editor.addCommand(
      // eslint-disable-next-line no-bitwise
      monaco.KeyMod.Shift | monaco.KeyMod.Alt | monaco.KeyCode.KeyF,
      () => {
        editor.getAction("editor.action.formatDocument").run();
      }
    );
  };
  
  // Map language to monaco language
  const getMonacoLanguage = (lang: string): string => {
    const languageMap: Record<string, string> = {
      javascript: "javascript",
      typescript: "typescript",
      html: "html",
      css: "css",
      json: "json",
      text: "plaintext",
    };
    
    return languageMap[lang.toLowerCase()] || "plaintext";
  };
  
  return (
    <div className={cn("border rounded-md overflow-hidden", className)}>
      <Editor
        height={height}
        language={getMonacoLanguage(language)}
        value={value}
        onChange={(val) => onChange(val || "")}
        onMount={handleEditorDidMount}
        options={{
          readOnly,
          minimap: { enabled: false },
          scrollBeyondLastLine: false,
          automaticLayout: true,
          scrollbar: {
            vertical: "auto",
            horizontal: "auto",
            verticalScrollbarSize: 10,
            horizontalScrollbarSize: 10,
          },
          fontSize: 14,
          fontFamily: '"Fira Code", Consolas, "Courier New", monospace',
          lineHeight: 1.5,
          roundedSelection: true,
          quickSuggestions: true,
          formatOnPaste: true,
          formatOnType: true,
        }}
        loading={
          <div className="flex items-center justify-center h-full">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        }
      />
      <div className="p-2 bg-gray-100 border-t text-xs text-gray-500 flex justify-between">
        <span>
          {readOnly ? "Read-only" : "Editable"} • {language.toUpperCase()}
        </span>
        <span>Press Shift+Alt+F to format</span>
      </div>
    </div>
  );
}

// Add global monaco declaration
declare global {
  const monaco: any;
}
