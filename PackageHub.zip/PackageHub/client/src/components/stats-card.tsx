import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: number | string;
  icon: string;
  color: "blue" | "green" | "purple" | "red" | "yellow";
}

export default function StatsCard({ title, value, icon, color }: StatsCardProps) {
  const colorClasses = {
    blue: {
      bg: "bg-blue-100",
      text: "text-blue-500",
    },
    green: {
      bg: "bg-green-100",
      text: "text-green-500",
    },
    purple: {
      bg: "bg-purple-100",
      text: "text-purple-500",
    },
    red: {
      bg: "bg-red-100",
      text: "text-red-500",
    },
    yellow: {
      bg: "bg-yellow-100",
      text: "text-yellow-500",
    },
  };
  
  // Format value as a number with commas
  const formattedValue = typeof value === "number" 
    ? value.toLocaleString()
    : value;
  
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center">
          <div className={cn("p-3 mr-4 rounded-full", colorClasses[color].bg)}>
            <i className={cn(`${icon} text-xl`, colorClasses[color].text)}></i>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <p className="text-2xl font-semibold text-gray-900">{formattedValue}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
