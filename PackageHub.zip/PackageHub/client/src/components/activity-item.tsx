import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";
import { ActivityWithDetails } from "@shared/schema";

interface ActivityItemProps {
  activity: ActivityWithDetails;
}

export default function ActivityItem({ activity }: ActivityItemProps) {
  // Format the activity action to show a user-friendly message
  const formatActivityMessage = (activity: ActivityWithDetails): string => {
    if (activity.action) {
      return activity.action;
    }
    
    // Fallback message if no specific message is provided
    if (activity.packageId && activity.package) {
      return `Interacted with package "${activity.package.name}"`;
    }
    
    return "Unknown activity";
  };
  
  // Get relative time (e.g., "4 hours ago")
  const getRelativeTime = (date: Date | string): string => {
    try {
      return formatDistanceToNow(new Date(date), { addSuffix: true });
    } catch (error) {
      return "some time ago";
    }
  };
  
  // Determine if the activity has a linkable target
  const getLinkForActivity = (activity: ActivityWithDetails): string | null => {
    if (activity.packageId) {
      return `/packages/view/${activity.packageId}`;
    }
    return null;
  };
  
  const link = getLinkForActivity(activity);
  const message = formatActivityMessage(activity);
  const relativeTime = getRelativeTime(activity.createdAt);
  
  return (
    <li>
      {link ? (
        <Link href={link} className="block hover:bg-gray-50">
          <ActivityContent message={message} relativeTime={relativeTime} />
        </Link>
      ) : (
        <div className="hover:bg-gray-50">
          <ActivityContent message={message} relativeTime={relativeTime} />
        </div>
      )}
    </li>
  );
}

// Separated component for the activity content
function ActivityContent({ message, relativeTime }: { message: string; relativeTime: string }) {
  return (
    <div className="flex items-center px-4 py-4 sm:px-6">
      <div className="flex-1 min-w-0 sm:flex sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium text-primary truncate">{message}</p>
          <p className="mt-1 text-sm text-gray-500">{relativeTime}</p>
        </div>
      </div>
      <div className="flex-shrink-0 ml-5">
        <i className="ri-arrow-right-line text-gray-400"></i>
      </div>
    </div>
  );
}
