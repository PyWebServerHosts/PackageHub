import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { LogOut, Home, Package2, Upload, Search, Star, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export default function SidebarNav() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const navItems = [
    {
      name: "Dashboard",
      icon: <Home className="w-6 h-6" />,
      href: "/",
      active: location === "/",
    },
    {
      name: "My Packages",
      icon: <Package2 className="w-6 h-6" />,
      href: "/packages/my",
      active: location === "/packages/my",
    },
    {
      name: "Upload Package",
      icon: <Upload className="w-6 h-6" />,
      href: "/packages/edit",
      active: location === "/packages/edit",
    },
    {
      name: "Discover",
      icon: <Search className="w-6 h-6" />,
      href: "/packages",
      active: location === "/packages",
    },
    {
      name: "Favorites",
      icon: <Star className="w-6 h-6" />,
      href: "/favorites",
      active: location === "/favorites",
    },
    {
      name: "Settings",
      icon: <Settings className="w-6 h-6" />,
      href: "/settings",
      active: location === "/settings",
    },
  ];
  
  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 bg-gray-800 border-r border-gray-700">
        <div className="flex items-center justify-center h-16 px-4 bg-gray-900">
          <h1 className="text-xl font-bold text-white">PackageHub</h1>
        </div>
        <div className="flex flex-col flex-grow px-4 mt-5">
          <nav className="flex-1 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center px-2 py-2 text-sm font-medium rounded-md group",
                  item.active
                    ? "text-white bg-gray-900"
                    : "text-gray-300 hover:bg-gray-700 hover:text-white"
                )}
              >
                {item.icon}
                <span className="ml-3">{item.name}</span>
              </Link>
            ))}
          </nav>
          
          {user && (
            <div className="mt-auto mb-5">
              <div className="pt-2 mt-2 space-y-1 border-t border-gray-700">
                <div className="flex items-center px-2 py-2 text-sm font-medium text-gray-300 rounded-md group">
                  <Avatar className="w-8 h-8 mr-3">
                    <AvatarFallback className="bg-primary text-white">
                      {user.username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>{user.username}</div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="ml-auto text-gray-400 hover:text-white"
                    onClick={handleLogout}
                    disabled={logoutMutation.isPending}
                  >
                    <LogOut className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
