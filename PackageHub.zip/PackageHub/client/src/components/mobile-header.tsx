import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Home, Package2, Upload, Search, Star, Settings, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

export default function MobileHeader() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const navItems = [
    {
      name: "Dashboard",
      icon: <Home className="w-5 h-5 mr-2" />,
      href: "/",
      active: location === "/",
    },
    {
      name: "My Packages",
      icon: <Package2 className="w-5 h-5 mr-2" />,
      href: "/packages/my",
      active: location === "/packages/my",
    },
    {
      name: "Upload Package",
      icon: <Upload className="w-5 h-5 mr-2" />,
      href: "/packages/edit",
      active: location === "/packages/edit",
    },
    {
      name: "Discover",
      icon: <Search className="w-5 h-5 mr-2" />,
      href: "/packages",
      active: location === "/packages",
    },
    {
      name: "Favorites",
      icon: <Star className="w-5 h-5 mr-2" />,
      href: "/favorites",
      active: location === "/favorites",
    },
    {
      name: "Settings",
      icon: <Settings className="w-5 h-5 mr-2" />,
      href: "/settings",
      active: location === "/settings",
    },
  ];
  
  return (
    <div className="relative z-10 flex items-center justify-between flex-shrink-0 h-16 bg-white border-b border-gray-200 md:hidden">
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" className="px-4 text-gray-500">
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <div className="flex flex-col h-full bg-gray-800">
            <div className="flex items-center justify-between h-16 px-4 bg-gray-900">
              <h1 className="text-xl font-bold text-white">PackageHub</h1>
              <Button
                variant="ghost"
                size="icon"
                className="text-gray-400 hover:text-white"
                onClick={() => setOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
            <div className="flex flex-col flex-grow px-4 mt-5">
              <nav className="flex-1 space-y-1">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      "flex items-center px-2 py-2 text-sm font-medium rounded-md group",
                      item.active
                        ? "text-white bg-gray-900"
                        : "text-gray-300 hover:bg-gray-700 hover:text-white"
                    )}
                    onClick={() => setOpen(false)}
                  >
                    {item.icon}
                    <span>{item.name}</span>
                  </Link>
                ))}
              </nav>
              
              {user && (
                <div className="mt-auto mb-5">
                  <div className="pt-2 mt-2 space-y-1 border-t border-gray-700">
                    <div className="flex items-center px-2 py-2 text-sm font-medium text-gray-300 rounded-md group">
                      <Avatar className="w-8 h-8 mr-3">
                        <AvatarFallback className="bg-primary text-white">
                          {user.username.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>{user.username}</div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="ml-auto text-gray-400 hover:text-white"
                        onClick={() => {
                          handleLogout();
                          setOpen(false);
                        }}
                        disabled={logoutMutation.isPending}
                      >
                        <LogOut className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <div className="flex items-center px-4">
        <div className="flex-shrink-0">
          <h1 className="text-lg font-bold text-gray-900">PackageHub</h1>
        </div>
      </div>

      <div className="flex items-center px-4">
        {user ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-primary text-white">
                    {user.username.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem className="font-medium">
                Signed in as {user.username}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/packages/my">My Packages</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/favorites">Favorites</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">Settings</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} disabled={logoutMutation.isPending}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Button variant="default" size="sm" asChild>
            <Link href="/auth">Log in</Link>
          </Button>
        )}
      </div>
    </div>
  );
}
