import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Download, Star, Eye } from "lucide-react";
import { PackageWithDetails } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

interface PackageCardProps {
  package: PackageWithDetails;
}

export default function PackageCard({ package: pkg }: PackageCardProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [isFavorited, setIsFavorited] = useState(false);
  
  // Download mutation
  const downloadMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/packages/${pkg.id}/download`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/packages/popular"] });
      queryClient.invalidateQueries({ queryKey: [`/api/packages/${pkg.id}`] });
      toast({
        title: "Package downloaded",
        description: `You've downloaded ${pkg.name}`,
      });
    },
  });
  
  // Favorite mutation
  const favoriteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/packages/${pkg.id}/favorite`, {
        add: !isFavorited,
      });
    },
    onSuccess: () => {
      setIsFavorited(!isFavorited);
      queryClient.invalidateQueries({ queryKey: ["/api/packages/popular"] });
      queryClient.invalidateQueries({ queryKey: [`/api/packages/${pkg.id}`] });
      toast({
        title: isFavorited ? "Removed from favorites" : "Added to favorites",
        description: isFavorited
          ? `${pkg.name} has been removed from your favorites`
          : `${pkg.name} has been added to your favorites`,
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update favorites",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle download button click
  const handleDownload = () => {
    downloadMutation.mutate();
  };
  
  // Handle favorite button click
  const handleFavorite = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to favorite packages",
        variant: "destructive",
      });
      return;
    }
    
    favoriteMutation.mutate();
  };
  
  // Handle view button click
  const handleView = () => {
    navigate(`/packages/view/${pkg.id}`);
  };
  
  return (
    <Card className="overflow-hidden">
      <div className="px-4 py-5 sm:p-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium leading-6 text-gray-900">{pkg.name}</h3>
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            v{pkg.latestVersion?.version || "1.0.0"}
          </Badge>
        </div>
        <div className="mt-2 max-w-xl text-sm text-gray-500">
          <p>{pkg.description || "No description provided."}</p>
        </div>
        <div className="flex items-center mt-3 text-sm text-gray-500">
          <span className="flex items-center mr-4">
            <Download className="mr-1 h-4 w-4" />
            {pkg.downloads}
          </span>
          <span className="flex items-center">
            <Star className="mr-1 h-4 w-4" />
            {pkg.favorites}
          </span>
          <span className="flex items-center ml-auto text-primary">
            @{pkg.user.username}
          </span>
        </div>
        <div className="mt-4 flex justify-end space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleFavorite}
            disabled={favoriteMutation.isPending}
          >
            <Star className={`h-4 w-4 ${isFavorited ? "fill-yellow-400" : ""}`} />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownload}
            disabled={downloadMutation.isPending}
          >
            <Download className="mr-1 h-4 w-4" />
            Download
          </Button>
          <Button size="sm" onClick={handleView}>
            <Eye className="mr-1 h-4 w-4" />
            View
          </Button>
        </div>
      </div>
    </Card>
  );
}
