import { Switch, Route, useLocation, Redirect } from "wouter";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import HomePage from "@/pages/home-page";
import PackageEditor from "@/pages/package-editor";
import PackageBrowser from "@/pages/package-browser";
import PackageView from "@/pages/package-view";
import FavoritesPage from "@/pages/favorites-page";
import SettingsPage from "@/pages/settings-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";

// Create a route component that renders PackageBrowser with userOnly=true
function MyPackages() {
  return <PackageBrowser userOnly={true} />;
}

function AppRoutes() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={HomePage} />
      <ProtectedRoute path="/packages/edit/:id?" component={PackageEditor} />
      <ProtectedRoute path="/packages/my" component={MyPackages} />
      <ProtectedRoute path="/favorites" component={FavoritesPage} />
      <ProtectedRoute path="/settings" component={SettingsPage} />
      <Route path="/packages" component={PackageBrowser} />
      <Route path="/packages/view/:id" component={PackageView} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/pkg/:username/@:version/:fileName.:extension" component={PackageView} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppRoutes />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
