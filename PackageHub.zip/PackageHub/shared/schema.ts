import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Package schema
export const packages = pgTable("packages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  userId: integer("user_id").notNull(),
  downloads: integer("downloads").default(0),
  favorites: integer("favorites").default(0),
  isPublic: boolean("is_public").default(true),
  minify: boolean("minify").default(false),
  enableCache: boolean("enable_cache").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPackageSchema = createInsertSchema(packages).pick({
  name: true,
  description: true,
  userId: true,
  isPublic: true,
  minify: true,
  enableCache: true,
});

export type InsertPackage = z.infer<typeof insertPackageSchema>;
export type Package = typeof packages.$inferSelect;

// Package version schema
export const packageVersions = pgTable("package_versions", {
  id: serial("id").primaryKey(),
  packageId: integer("package_id").notNull(),
  version: text("version").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPackageVersionSchema = createInsertSchema(packageVersions).pick({
  packageId: true,
  version: true,
});

export type InsertPackageVersion = z.infer<typeof insertPackageVersionSchema>;
export type PackageVersion = typeof packageVersions.$inferSelect;

// Package file schema
export const packageFiles = pgTable("package_files", {
  id: serial("id").primaryKey(),
  packageVersionId: integer("package_version_id").notNull(),
  fileName: text("file_name").notNull(),
  extension: text("extension").notNull(),
  content: text("content").notNull(),
  language: text("language").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPackageFileSchema = createInsertSchema(packageFiles).pick({
  packageVersionId: true,
  fileName: true,
  extension: true,
  content: true,
  language: true,
});

export type InsertPackageFile = z.infer<typeof insertPackageFileSchema>;
export type PackageFile = typeof packageFiles.$inferSelect;

// Activity schema
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  packageId: integer("package_id"),
  packageVersionId: integer("package_version_id"),
  packageFileId: integer("package_file_id"),
  action: text("action").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  userId: true,
  packageId: true,
  packageVersionId: true,
  packageFileId: true,
  action: true,
});

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// Package with related data
export type PackageWithDetails = Package & {
  user: { username: string };
  latestVersion: { version: string };
};

// Activity with related data
export type ActivityWithDetails = Activity & {
  user: { username: string };
  package?: { name: string };
  packageVersion?: { version: string };
  packageFile?: { fileName: string; extension: string };
};
