import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { 
  insertPackageSchema, 
  insertPackageVersionSchema, 
  insertPackageFileSchema,
  insertActivitySchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Helper for checking authentication
  const ensureAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // ============== PACKAGE ROUTES ==============
  
  // Get all packages (or user's packages)
  app.get("/api/packages", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const packages = await storage.getPackages(userId, limit);
      res.json(packages);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch packages" });
    }
  });

  // Get popular packages
  app.get("/api/packages/popular", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const packages = await storage.getPopularPackages(limit);
      res.json(packages);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch popular packages" });
    }
  });
  
  // Search packages
  app.get("/api/packages/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const packages = await storage.searchPackages(query, limit);
      res.json(packages);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to search packages" });
    }
  });

  // Get a single package
  app.get("/api/packages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pkg = await storage.getPackage(id);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      const user = await storage.getUser(pkg.userId);
      const versions = await storage.getPackageVersions(id);
      const latestVersion = versions.length > 0 
        ? versions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0]
        : undefined;
      
      res.json({
        ...pkg,
        user: { username: user?.username || "unknown" },
        latestVersion: latestVersion ? { version: latestVersion.version } : undefined,
        versions
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch package" });
    }
  });

  // Create a new package
  app.post("/api/packages", ensureAuthenticated, async (req, res) => {
    try {
      const validation = insertPackageSchema.safeParse({
        ...req.body,
        userId: req.user!.id
      });
      
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid package data", errors: validation.error.errors });
      }
      
      const pkg = await storage.createPackage(validation.data);
      
      // Create activity record
      await storage.createActivity({
        userId: req.user!.id,
        packageId: pkg.id,
        action: `Created package "${pkg.name}"`
      });
      
      res.status(201).json(pkg);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to create package" });
    }
  });

  // Update a package
  app.patch("/api/packages/:id", ensureAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pkg = await storage.getPackage(id);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      if (pkg.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized to update this package" });
      }
      
      // Validate request body
      const updateSchema = z.object({
        name: z.string().optional(),
        description: z.string().optional(),
        isPublic: z.boolean().optional(),
        minify: z.boolean().optional(),
        enableCache: z.boolean().optional()
      });
      
      const validation = updateSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid package data", errors: validation.error.errors });
      }
      
      const updatedPkg = await storage.updatePackage(id, validation.data);
      
      // Create activity record
      await storage.createActivity({
        userId: req.user!.id,
        packageId: pkg.id,
        action: `Updated package "${pkg.name}"`
      });
      
      res.json(updatedPkg);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to update package" });
    }
  });

  // Delete a package
  app.delete("/api/packages/:id", ensureAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pkg = await storage.getPackage(id);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      if (pkg.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized to delete this package" });
      }
      
      const deleted = await storage.deletePackage(id);
      
      if (deleted) {
        // Create activity record
        await storage.createActivity({
          userId: req.user!.id,
          action: `Deleted package "${pkg.name}"`
        });
        
        res.status(204).end();
      } else {
        res.status(500).json({ message: "Failed to delete package" });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to delete package" });
    }
  });

  // Increment package downloads
  app.post("/api/packages/:id/download", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pkg = await storage.getPackage(id);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      await storage.incrementPackageDownloads(id);
      
      res.status(204).end();
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to increment downloads" });
    }
  });

  // Toggle package favorite
  app.post("/api/packages/:id/favorite", ensureAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pkg = await storage.getPackage(id);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      const add = req.body.add === true;
      await storage.togglePackageFavorite(id, add);
      
      // Create activity record if adding favorite
      if (add) {
        await storage.createActivity({
          userId: req.user!.id,
          packageId: pkg.id,
          action: `Favorited package "${pkg.name}"`
        });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to toggle favorite" });
    }
  });

  // ============== PACKAGE VERSION ROUTES ==============
  
  // Get all versions for a package
  app.get("/api/packages/:packageId/versions", async (req, res) => {
    try {
      const packageId = parseInt(req.params.packageId);
      const pkg = await storage.getPackage(packageId);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      const versions = await storage.getPackageVersions(packageId);
      res.json(versions);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch package versions" });
    }
  });

  // Create a new version
  app.post("/api/packages/:packageId/versions", ensureAuthenticated, async (req, res) => {
    try {
      const packageId = parseInt(req.params.packageId);
      const pkg = await storage.getPackage(packageId);
      
      if (!pkg) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      if (pkg.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized to create version for this package" });
      }
      
      // Validate request body
      const validation = insertPackageVersionSchema.safeParse({
        ...req.body,
        packageId
      });
      
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid version data", errors: validation.error.errors });
      }
      
      // Check if version already exists
      const existingVersion = await storage.getPackageVersionByVersion(packageId, validation.data.version);
      
      if (existingVersion) {
        return res.status(400).json({ message: "Version already exists" });
      }
      
      const version = await storage.createPackageVersion(validation.data);
      
      // Create activity record
      await storage.createActivity({
        userId: req.user!.id,
        packageId: pkg.id,
        packageVersionId: version.id,
        action: `Created version ${version.version} for package "${pkg.name}"`
      });
      
      res.status(201).json(version);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to create package version" });
    }
  });

  // ============== PACKAGE FILE ROUTES ==============
  
  // Get all files for a package version
  app.get("/api/versions/:versionId/files", async (req, res) => {
    try {
      const versionId = parseInt(req.params.versionId);
      const version = await storage.getPackageVersion(versionId);
      
      if (!version) {
        return res.status(404).json({ message: "Version not found" });
      }
      
      const files = await storage.getPackageFiles(versionId);
      res.json(files);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch package files" });
    }
  });

  // Get a specific file
  app.get("/api/files/:fileId", async (req, res) => {
    try {
      const fileId = parseInt(req.params.fileId);
      const file = await storage.getPackageFile(fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.json(file);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch file" });
    }
  });

  // Create a new file
  app.post("/api/versions/:versionId/files", ensureAuthenticated, async (req, res) => {
    try {
      const versionId = parseInt(req.params.versionId);
      const version = await storage.getPackageVersion(versionId);
      
      if (!version) {
        return res.status(404).json({ message: "Version not found" });
      }
      
      const pkg = await storage.getPackage(version.packageId);
      
      if (pkg && pkg.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized to create file for this package" });
      }
      
      // Validate request body
      const validation = insertPackageFileSchema.safeParse({
        ...req.body,
        packageVersionId: versionId
      });
      
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid file data", errors: validation.error.errors });
      }
      
      // Check if file already exists
      const existingFile = await storage.getPackageFileByName(
        versionId, 
        validation.data.fileName, 
        validation.data.extension
      );
      
      if (existingFile) {
        return res.status(400).json({ message: "File already exists with this name and extension" });
      }
      
      const file = await storage.createPackageFile(validation.data);
      
      // Create activity record
      if (pkg) {
        await storage.createActivity({
          userId: req.user!.id,
          packageId: pkg.id,
          packageVersionId: version.id,
          packageFileId: file.id,
          action: `Created file ${file.fileName}.${file.extension} for version ${version.version} of package "${pkg.name}"`
        });
      }
      
      res.status(201).json(file);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to create file" });
    }
  });

  // Update a file
  app.patch("/api/files/:fileId", ensureAuthenticated, async (req, res) => {
    try {
      const fileId = parseInt(req.params.fileId);
      const file = await storage.getPackageFile(fileId);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      const version = await storage.getPackageVersion(file.packageVersionId);
      
      if (!version) {
        return res.status(404).json({ message: "Version not found" });
      }
      
      const pkg = await storage.getPackage(version.packageId);
      
      if (pkg && pkg.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized to update this file" });
      }
      
      // Validate request body
      const updateSchema = z.object({
        fileName: z.string().optional(),
        extension: z.string().optional(),
        content: z.string().optional(),
        language: z.string().optional()
      });
      
      const validation = updateSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid file data", errors: validation.error.errors });
      }
      
      // If fileName or extension changed, check for conflicts
      if (validation.data.fileName || validation.data.extension) {
        const newFileName = validation.data.fileName || file.fileName;
        const newExtension = validation.data.extension || file.extension;
        
        const existingFile = await storage.getPackageFileByName(
          file.packageVersionId, 
          newFileName, 
          newExtension
        );
        
        if (existingFile && existingFile.id !== fileId) {
          return res.status(400).json({ message: "Another file already exists with this name and extension" });
        }
      }
      
      const updatedFile = await storage.updatePackageFile(fileId, validation.data);
      
      // Create activity record
      if (pkg) {
        await storage.createActivity({
          userId: req.user!.id,
          packageId: pkg.id,
          packageVersionId: version.id,
          packageFileId: file.id,
          action: `Updated file ${file.fileName}.${file.extension} for version ${version.version} of package "${pkg.name}"`
        });
      }
      
      res.json(updatedFile);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to update file" });
    }
  });

  // ============== ACTIVITY ROUTES ==============
  
  // Get user activities
  app.get("/api/activities", ensureAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const activities = await storage.getActivities(req.user!.id, limit);
      res.json(activities);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // ============== PACKAGE ACCESS ROUTE ==============
  
  // Serve package files
  app.get("/pkg/:username/@:version/:fileName.:extension", async (req, res) => {
    try {
      const { username, version, fileName, extension } = req.params;
      
      const packageData = await storage.getPackageByPath(username, version, fileName, extension);
      
      if (!packageData) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      const { file, pkg, user } = packageData;
      
      // Check if package is public
      if (!pkg.isPublic && (!req.isAuthenticated() || req.user!.id !== pkg.userId)) {
        return res.status(403).json({ message: "This package is private" });
      }
      
      // Increment download count
      await storage.incrementPackageDownloads(pkg.id);
      
      // Create activity record if user is authenticated
      if (req.isAuthenticated()) {
        await storage.createActivity({
          userId: req.user!.id,
          packageId: pkg.id,
          action: `Downloaded package "${pkg.name}" version ${version}`
        });
      }
      
      // Set content type based on extension
      const contentTypes: Record<string, string> = {
        js: 'application/javascript',
        ts: 'application/typescript',
        css: 'text/css',
        html: 'text/html',
        json: 'application/json',
        txt: 'text/plain',
      };
      
      const contentType = contentTypes[extension.toLowerCase()] || 'text/plain';
      
      // If minify is enabled, we would minify here
      const content = file.content;
      
      res.set('Content-Type', contentType);
      res.send(content);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to serve package" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
