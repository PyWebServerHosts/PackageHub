import { users, packages, packageVersions, packageFiles, activities } from "@shared/schema";
import type { 
  User, 
  InsertUser, 
  Package, 
  InsertPackage, 
  PackageVersion, 
  InsertPackageVersion, 
  PackageFile, 
  InsertPackageFile, 
  Activity, 
  InsertActivity,
  PackageWithDetails,
  ActivityWithDetails
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Package operations
  getPackage(id: number): Promise<Package | undefined>;
  getPackages(userId?: number, limit?: number): Promise<PackageWithDetails[]>;
  getPopularPackages(limit?: number): Promise<PackageWithDetails[]>;
  searchPackages(query: string, limit?: number): Promise<PackageWithDetails[]>;
  createPackage(pkg: InsertPackage): Promise<Package>;
  updatePackage(id: number, pkg: Partial<Package>): Promise<Package | undefined>;
  incrementPackageDownloads(id: number): Promise<void>;
  togglePackageFavorite(id: number, add: boolean): Promise<void>;
  deletePackage(id: number): Promise<boolean>;

  // Package version operations
  getPackageVersion(id: number): Promise<PackageVersion | undefined>;
  getPackageVersions(packageId: number): Promise<PackageVersion[]>;
  getPackageVersionByVersion(packageId: number, version: string): Promise<PackageVersion | undefined>;
  createPackageVersion(version: InsertPackageVersion): Promise<PackageVersion>;

  // Package file operations
  getPackageFile(id: number): Promise<PackageFile | undefined>;
  getPackageFiles(packageVersionId: number): Promise<PackageFile[]>;
  getPackageFileByName(packageVersionId: number, fileName: string, extension: string): Promise<PackageFile | undefined>;
  createPackageFile(file: InsertPackageFile): Promise<PackageFile>;
  updatePackageFile(id: number, file: Partial<PackageFile>): Promise<PackageFile | undefined>;
  
  // Activity operations
  getActivities(userId: number, limit: number): Promise<ActivityWithDetails[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Get package by username, version, filename
  getPackageByPath(username: string, version: string, fileName: string, extension: string): Promise<{ 
    file: PackageFile, 
    user: User, 
    pkg: Package, 
    version: PackageVersion 
  } | undefined>;

  // Session storage
  sessionStore: any;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private packagesMap: Map<number, Package>;
  private packageVersionsMap: Map<number, PackageVersion>;
  private packageFilesMap: Map<number, PackageFile>;
  private activitiesMap: Map<number, Activity>;
  
  private userIdCounter: number;
  private packageIdCounter: number;
  private packageVersionIdCounter: number;
  private packageFileIdCounter: number;
  private activityIdCounter: number;
  
  sessionStore: any;

  constructor() {
    this.usersMap = new Map();
    this.packagesMap = new Map();
    this.packageVersionsMap = new Map();
    this.packageFilesMap = new Map();
    this.activitiesMap = new Map();
    
    this.userIdCounter = 1;
    this.packageIdCounter = 1;
    this.packageVersionIdCounter = 1;
    this.packageFileIdCounter = 1;
    this.activityIdCounter = 1;
    
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    }) as any;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.usersMap.set(id, user);
    return user;
  }

  // Package operations
  async getPackage(id: number): Promise<Package | undefined> {
    return this.packagesMap.get(id);
  }

  async getPackages(userId?: number, limit?: number): Promise<PackageWithDetails[]> {
    let packages = Array.from(this.packagesMap.values());
    
    if (userId) {
      packages = packages.filter(pkg => pkg.userId === userId);
    }
    
    const result = await Promise.all(packages.map(async pkg => {
      const user = await this.getUser(pkg.userId);
      const versions = await this.getPackageVersions(pkg.id);
      const latestVersion = versions.length > 0 
        ? versions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0]
        : { version: "0.0.0" };
      
      return {
        ...pkg,
        user: { username: user?.username || "unknown" },
        latestVersion: { version: latestVersion.version }
      };
    }));
    
    // Sort by newest first
    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return limit ? result.slice(0, limit) : result;
  }

  async getPopularPackages(limit: number = 5): Promise<PackageWithDetails[]> {
    const packages = Array.from(this.packagesMap.values());
    
    // Sort by downloads and favorites
    packages.sort((a, b) => ((b.downloads || 0) + (b.favorites || 0)) - ((a.downloads || 0) + (a.favorites || 0)));
    
    const result = await Promise.all(packages.map(async pkg => {
      const user = await this.getUser(pkg.userId);
      const versions = await this.getPackageVersions(pkg.id);
      const latestVersion = versions.length > 0 
        ? versions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0]
        : { version: "0.0.0" };
      
      return {
        ...pkg,
        user: { username: user?.username || "unknown" },
        latestVersion: { version: latestVersion.version }
      };
    }));
    
    return result.slice(0, limit);
  }

  async searchPackages(query: string, limit: number = 20): Promise<PackageWithDetails[]> {
    const packages = Array.from(this.packagesMap.values());
    
    const filtered = packages.filter(pkg => 
      pkg.name.toLowerCase().includes(query.toLowerCase()) || 
      (pkg.description && pkg.description.toLowerCase().includes(query.toLowerCase()))
    );
    
    const result = await Promise.all(filtered.map(async pkg => {
      const user = await this.getUser(pkg.userId);
      const versions = await this.getPackageVersions(pkg.id);
      const latestVersion = versions.length > 0 
        ? versions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0]
        : { version: "0.0.0" };
      
      return {
        ...pkg,
        user: { username: user?.username || "unknown" },
        latestVersion: { version: latestVersion.version }
      };
    }));
    
    return limit ? result.slice(0, limit) : result;
  }

  async createPackage(insertPackage: InsertPackage): Promise<Package> {
    const id = this.packageIdCounter++;
    const now = new Date();
    const pkg: Package = { 
      ...insertPackage, 
      id, 
      downloads: 0, 
      favorites: 0,
      createdAt: now,
      updatedAt: now
    };
    this.packagesMap.set(id, pkg);
    return pkg;
  }

  async updatePackage(id: number, updates: Partial<Package>): Promise<Package | undefined> {
    const pkg = this.packagesMap.get(id);
    if (!pkg) return undefined;
    
    const updatedPkg = { 
      ...pkg, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.packagesMap.set(id, updatedPkg);
    return updatedPkg;
  }

  async incrementPackageDownloads(id: number): Promise<void> {
    const pkg = this.packagesMap.get(id);
    if (pkg) {
      this.packagesMap.set(id, { 
        ...pkg, 
        downloads: (pkg.downloads || 0) + 1,
        updatedAt: new Date()
      });
    }
  }

  async togglePackageFavorite(id: number, add: boolean): Promise<void> {
    const pkg = this.packagesMap.get(id);
    if (pkg) {
      this.packagesMap.set(id, { 
        ...pkg, 
        favorites: add ? (pkg.favorites || 0) + 1 : Math.max(0, (pkg.favorites || 0) - 1),
        updatedAt: new Date()
      });
    }
  }

  async deletePackage(id: number): Promise<boolean> {
    return this.packagesMap.delete(id);
  }

  // Package version operations
  async getPackageVersion(id: number): Promise<PackageVersion | undefined> {
    return this.packageVersionsMap.get(id);
  }

  async getPackageVersions(packageId: number): Promise<PackageVersion[]> {
    return Array.from(this.packageVersionsMap.values())
      .filter(version => version.packageId === packageId);
  }

  async getPackageVersionByVersion(packageId: number, version: string): Promise<PackageVersion | undefined> {
    return Array.from(this.packageVersionsMap.values())
      .find(v => v.packageId === packageId && v.version === version);
  }

  async createPackageVersion(insertVersion: InsertPackageVersion): Promise<PackageVersion> {
    const id = this.packageVersionIdCounter++;
    const version: PackageVersion = { 
      ...insertVersion, 
      id, 
      createdAt: new Date() 
    };
    this.packageVersionsMap.set(id, version);
    return version;
  }

  // Package file operations
  async getPackageFile(id: number): Promise<PackageFile | undefined> {
    return this.packageFilesMap.get(id);
  }

  async getPackageFiles(packageVersionId: number): Promise<PackageFile[]> {
    return Array.from(this.packageFilesMap.values())
      .filter(file => file.packageVersionId === packageVersionId);
  }

  async getPackageFileByName(packageVersionId: number, fileName: string, extension: string): Promise<PackageFile | undefined> {
    return Array.from(this.packageFilesMap.values())
      .find(file => 
        file.packageVersionId === packageVersionId && 
        file.fileName === fileName && 
        file.extension === extension
      );
  }

  async createPackageFile(insertFile: InsertPackageFile): Promise<PackageFile> {
    const id = this.packageFileIdCounter++;
    const now = new Date();
    const file: PackageFile = { 
      ...insertFile, 
      id, 
      createdAt: now,
      updatedAt: now
    };
    this.packageFilesMap.set(id, file);
    return file;
  }

  async updatePackageFile(id: number, updates: Partial<PackageFile>): Promise<PackageFile | undefined> {
    const file = this.packageFilesMap.get(id);
    if (!file) return undefined;
    
    const updatedFile = { 
      ...file, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.packageFilesMap.set(id, updatedFile);
    return updatedFile;
  }

  // Activity operations
  async getActivities(userId: number, limit: number = 5): Promise<ActivityWithDetails[]> {
    const activities = Array.from(this.activitiesMap.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
    
    return Promise.all(activities.map(async activity => {
      const user = await this.getUser(activity.userId);
      
      let packageData = undefined;
      if (activity.packageId) {
        const pkg = await this.getPackage(activity.packageId);
        packageData = pkg ? { name: pkg.name } : undefined;
      }
      
      let versionData = undefined;
      if (activity.packageVersionId) {
        const version = await this.getPackageVersion(activity.packageVersionId);
        versionData = version ? { version: version.version } : undefined;
      }
      
      let fileData = undefined;
      if (activity.packageFileId) {
        const file = await this.getPackageFile(activity.packageFileId);
        fileData = file ? { fileName: file.fileName, extension: file.extension } : undefined;
      }
      
      return {
        ...activity,
        user: { username: user?.username || "unknown" },
        package: packageData,
        packageVersion: versionData,
        packageFile: fileData
      };
    }));
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      createdAt: new Date() 
    };
    this.activitiesMap.set(id, activity);
    return activity;
  }

  // Get package by path
  async getPackageByPath(username: string, version: string, fileName: string, extension: string): Promise<{ 
    file: PackageFile, 
    user: User, 
    pkg: Package, 
    version: PackageVersion 
  } | undefined> {
    // Find user by username
    const user = await this.getUserByUsername(username);
    if (!user) return undefined;
    
    // Find all packages by this user
    const userPackages = Array.from(this.packagesMap.values())
      .filter(pkg => pkg.userId === user.id);
    
    // For each package, look for the version and file
    for (const pkg of userPackages) {
      const packageVersions = await this.getPackageVersions(pkg.id);
      const packageVersion = packageVersions.find(v => v.version === version);
      
      if (packageVersion) {
        const file = await this.getPackageFileByName(packageVersion.id, fileName, extension);
        
        if (file) {
          return {
            file,
            user,
            pkg,
            version: packageVersion
          };
        }
      }
    }
    
    return undefined;
  }
}

export const storage = new MemStorage();
